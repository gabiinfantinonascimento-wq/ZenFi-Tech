# ZenFi Tech para iOS

App iOS (SwiftUI + WKWebView) equivalente ao APK: abre https://zenfi-tech-afgr.onrender.com/
com ícone e splash do ZenFi Tech, pull-to-refresh, tela de erro com "Tentar novamente",
links externos no Safari, tel:/mailto:/WhatsApp fora do app e cookies persistentes.

## Como gerar o app (precisa de um Mac com Xcode 15+)

Opção A, com XcodeGen (mais rápido):
1. `brew install xcodegen`
2. Na pasta do projeto: `xcodegen generate`
3. Abra `ZenFiTech.xcodeproj`, escolha seu time em Signing & Capabilities e rode no iPhone.

Opção B, manual:
1. Xcode > File > New > Project > iOS App (SwiftUI), nome ZenFiTech.
2. Apague o ContentView e o App gerados e arraste para o projeto todos os arquivos
   .swift e a pasta Assets.xcassets de `ZenFiTech/`.
3. Em Info (target), defina Display Name "ZenFi Tech", orientação só Portrait e as
   descrições de câmera, fotos, microfone e localização (textos em project.yml).

## Para publicar na App Store
Conta Apple Developer (US$ 99/ano). A Apple costuma rejeitar apps que são só um
site embrulhado (guideline 4.2), então vale incluir algo nativo, como notificações push.
Para uso próprio ou da equipe, TestFlight resolve.

## Ajustes
Endereço e domínios internos ficam em `ZenFiTech/Config.swift`.

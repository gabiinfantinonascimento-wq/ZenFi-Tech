import Foundation

enum Config {
    /// Mesmo endereço do app Android (targetUrl).
    static let startURL = URL(string: "https://zenfi-tech-afgr.onrender.com/")!

    /// Domínios que abrem dentro do app. Qualquer outro abre no Safari.
    static let internalHosts: [String] = ["onrender.com"]

    /// Esquemas que o iOS deve abrir fora do app (telefone, e-mail, WhatsApp...).
    static let externalSchemes: Set<String> = ["tel", "mailto", "sms", "facetime", "whatsapp", "itms-apps", "maps"]
}

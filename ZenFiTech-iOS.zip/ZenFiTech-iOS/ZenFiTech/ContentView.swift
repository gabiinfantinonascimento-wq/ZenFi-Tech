import SwiftUI

struct ContentView: View {
    @StateObject private var model = WebViewModel()

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            WebView(model: model)
                .ignoresSafeArea(edges: .bottom)

            if model.isLoading && !model.hasLoadedOnce {
                SplashView()
                    .transition(.opacity)
            }

            if let message = model.errorMessage {
                ErrorView(message: message) { model.reload() }
                    .transition(.opacity)
            }
        }
        .animation(.easeOut(duration: 0.3), value: model.isLoading)
        .animation(.easeOut(duration: 0.3), value: model.errorMessage)
    }
}

struct SplashView: View {
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 20) {
                Image("SplashLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 220)
                ProgressView()
                    .progressViewStyle(.circular)
                    .tint(.accentColor)
            }
        }
    }
}

struct ErrorView: View {
    let message: String
    let retry: () -> Void

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 16) {
                Image(systemName: "wifi.exclamationmark")
                    .font(.system(size: 48))
                    .foregroundColor(.accentColor)
                Text("Não foi possível carregar")
                    .font(.headline)
                    .foregroundColor(.white)
                Text(message)
                    .font(.footnote)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.gray)
                    .padding(.horizontal, 32)
                Button("Tentar novamente", action: retry)
                    .buttonStyle(.borderedProminent)
                    .tint(.accentColor)
            }
        }
    }
}

# ZenFi Tech – Pagamentos (Mercado Pago)

Servidor que recebe os avisos (webhooks) do Mercado Pago e controla quem tem acesso ao plano de R$ 44,90.
Sem dependências: só Node 18+.

## Como funciona
- **Plano mensal** (`mpago.la/2Nqh34A`): ao autorizar, o usuário ganha acesso até a próxima cobrança + 3 dias de carência. Cancelado/pausado: mantém só o período já pago.
- **Pix** (`mpago.la/1sYSAgE`): pagamento aprovado de R$ 44,90 libera 31 dias. Não renova sozinho.
- O usuário é identificado pelo **e-mail** usado no pagamento (o mesmo da conta no app).
- O servidor sempre confirma o status na API do Mercado Pago e valida a assinatura do webhook.

## Passo a passo
1. Suba esta pasta no seu repositório do GitHub (o `.gitignore` já protege `.env` e `data/`).
2. Hospede em um serviço que rode Node (Render, Railway, Fly.io, VPS). **GitHub Pages não executa servidor**, serve só o site.
3. Configure as variáveis do `.env.example` no painel da hospedagem.
4. No Mercado Pago > Suas integrações > Webhooks, URL: `https://SEU-SERVIDOR/webhook/mercadopago`, com os eventos **Planos e assinaturas** (`subscription_preapproval`, `subscription_authorized_payment`) e **Pagamentos**. Copie a chave secreta para `MP_WEBHOOK_SECRET`.
5. Teste primeiro com credenciais de teste.

## Consultar acesso no seu app/backend
```
GET https://SEU-SERVIDOR/api/subscription?email=cliente@email.com
Authorization: Bearer SUA_APP_API_KEY
→ { "email": "...", "active": true, "accessUntil": "2026-12-05T...", "status": "authorized" }
```
Chame isso do **seu backend** (nunca coloque a chave no app/site) e bloqueie recursos pagos quando `active` for `false`.

## Banco de dados
`src/store.js` guarda em arquivo JSON. Em hospedagens com disco temporário (ex.: Render grátis) o arquivo some a cada deploy.
Para produção, reescreva só as 4 funções de `store.js` para o seu banco (MySQL, Postgres, Mongo...).

## Testes
`npm test` simula o Mercado Pago e valida: assinatura inválida, ativação, cancelamento, Pix e duplicidade.

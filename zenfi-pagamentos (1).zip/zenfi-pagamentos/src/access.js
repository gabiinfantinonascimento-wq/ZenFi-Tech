// Regras de acesso do plano.
const DAY = 24 * 60 * 60 * 1000;
const GRACE_DAYS = Number(process.env.GRACE_DAYS || 3);
const PIX_DAYS = Number(process.env.PIX_DAYS || 31);
const PLAN_AMOUNT = Number(process.env.PLAN_AMOUNT || 44.9);

const isActive = (user, now = Date.now()) =>
  !!(user && user.accessUntil && new Date(user.accessUntil).getTime() > now);

// Assinatura recorrente (preapproval)
// authorized -> acesso até a próxima cobrança + carência
// paused/cancelled -> mantém só o que já foi pago (não estende)
function fromPreapproval(pre, current) {
  const email = pre.payer_email || (pre.payer && pre.payer.email);
  const status = pre.status; // authorized | pending | paused | cancelled
  let accessUntil = current && current.accessUntil ? new Date(current.accessUntil).getTime() : 0;

  if (status === 'authorized') {
    const next = pre.next_payment_date ? new Date(pre.next_payment_date).getTime() : Date.now() + 30 * DAY;
    accessUntil = Math.max(accessUntil, next + GRACE_DAYS * DAY);
  }
  return {
    email,
    patch: {
      subscriptionId: pre.id,
      subscriptionStatus: status,
      accessUntil: accessUntil ? new Date(accessUntil).toISOString() : null,
    },
  };
}

// Pagamento avulso por Pix (aprovado e com o valor do plano)
function fromPixPayment(payment, current) {
  if (payment.status !== 'approved') return null;
  if (payment.payment_method_id !== 'pix') return null;
  if (Number(payment.transaction_amount) < PLAN_AMOUNT - 0.01) return null;
  const email = payment.payer && payment.payer.email;
  if (!email) return null;
  const base = Math.max(Date.now(), current && current.accessUntil ? new Date(current.accessUntil).getTime() : 0);
  return {
    email,
    patch: {
      lastPixPaymentId: String(payment.id),
      accessUntil: new Date(base + PIX_DAYS * DAY).toISOString(),
    },
  };
}

module.exports = { isActive, fromPreapproval, fromPixPayment };

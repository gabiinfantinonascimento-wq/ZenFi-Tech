// Cliente mínimo da API do Mercado Pago (somente leitura) + validação de assinatura do webhook.
const crypto = require('crypto');

const BASE = process.env.MP_API_BASE || 'https://api.mercadopago.com';

async function mpGet(pathname) {
  const res = await fetch(BASE + pathname, {
    headers: { Authorization: `Bearer ${process.env.MP_ACCESS_TOKEN}` },
  });
  if (!res.ok) throw new Error(`Mercado Pago ${pathname} -> HTTP ${res.status}`);
  return res.json();
}

const getPreapproval = (id) => mpGet(`/preapproval/${encodeURIComponent(id)}`);
const getAuthorizedPayment = (id) => mpGet(`/authorized_payments/${encodeURIComponent(id)}`);
const getPayment = (id) => mpGet(`/v1/payments/${encodeURIComponent(id)}`);

/**
 * Valida o header x-signature conforme a documentação do Mercado Pago:
 * manifest = "id:<data.id minúsculo>;request-id:<x-request-id>;ts:<ts>;"
 * assinatura = HMAC-SHA256(manifest, MP_WEBHOOK_SECRET)
 */
function verifySignature(headers, query, body) {
  const secret = process.env.MP_WEBHOOK_SECRET;
  if (!secret) return false;
  const header = headers['x-signature'] || '';
  const requestId = headers['x-request-id'] || '';
  const parts = Object.fromEntries(
    header.split(',').map((p) => p.trim().split('=').map((s) => s.trim()))
  );
  const { ts, v1 } = parts;
  if (!ts || !v1) return false;
  const dataId = String(query.get('data.id') || (body && body.data && body.data.id) || '').toLowerCase();
  const manifest = `id:${dataId};request-id:${requestId};ts:${ts};`;
  const expected = crypto.createHmac('sha256', secret).update(manifest).digest('hex');
  const a = Buffer.from(expected);
  const b = Buffer.from(v1);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

module.exports = { getPreapproval, getAuthorizedPayment, getPayment, verifySignature };

// Servidor sem dependências externas (somente Node >= 18).
const http = require('http');
const store = require('./store');
const mp = require('./mp');
const access = require('./access');

function readJson(req) {
  return new Promise((resolve) => {
    let raw = '';
    req.on('data', (c) => { raw += c; if (raw.length > 1e6) req.destroy(); });
    req.on('end', () => { try { resolve(JSON.parse(raw || '{}')); } catch { resolve({}); } });
  });
}
const send = (res, code, obj) => {
  res.writeHead(code, { 'content-type': 'application/json' });
  res.end(obj ? JSON.stringify(obj) : '');
};

async function handlePreapproval(id) {
  const pre = await mp.getPreapproval(id); // sempre confirma na API, nunca confia no corpo recebido
  if (!pre.payer_email) return;
  const { patch } = access.fromPreapproval(pre, store.getUser(pre.payer_email));
  store.upsertUser(pre.payer_email, patch);
  console.log(`Assinatura ${id} (${pre.status}) -> ${pre.payer_email}`);
}

async function handlePayment(id) {
  const payment = await mp.getPayment(id);
  const preId = payment.metadata && payment.metadata.preapproval_id;
  if (preId) return handlePreapproval(preId); // cobrança mensal da assinatura

  const current = payment.payer && payment.payer.email ? store.getUser(payment.payer.email) : null;
  const result = access.fromPixPayment(payment, current);
  if (!result) return;
  if (!store.markPaymentProcessed(String(payment.id))) return; // já processado
  store.upsertUser(result.email, result.patch);
  console.log(`Pix ${payment.id} aprovado -> ${result.email}`);
}

async function processWebhook(body, query) {
  const type = body.type || query.get('type') || body.topic;
  const id = (body.data && body.data.id) || query.get('data.id');
  if (!id) return;
  if (type === 'subscription_preapproval') await handlePreapproval(id);
  else if (type === 'subscription_authorized_payment') {
    const ap = await mp.getAuthorizedPayment(id);
    if (ap.preapproval_id) await handlePreapproval(ap.preapproval_id);
  } else if (type === 'payment') await handlePayment(id);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');

  if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true });

  if (req.method === 'POST' && url.pathname === '/webhook/mercadopago') {
    const body = await readJson(req);
    if (!mp.verifySignature(req.headers, url.searchParams, body)) return send(res, 401);
    send(res, 200); // responde rápido; o Mercado Pago reenvia se não receber 200
    try { await processWebhook(body, url.searchParams); }
    catch (err) { console.error('Erro no webhook:', err.message); }
    return;
  }

  if (req.method === 'GET' && url.pathname === '/api/subscription') {
    const key = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!process.env.APP_API_KEY || key !== process.env.APP_API_KEY) return send(res, 401);
    const email = url.searchParams.get('email');
    if (!email) return send(res, 400, { error: 'email obrigatório' });
    const user = store.getUser(email);
    return send(res, 200, {
      email: store.norm(email),
      active: access.isActive(user),
      accessUntil: user ? user.accessUntil : null,
      status: user ? user.subscriptionStatus || (user.lastPixPaymentId ? 'pix' : null) : null,
    });
  }

  send(res, 404);
});

if (require.main === module) {
  const port = process.env.PORT || 3000;
  server.listen(port, () => console.log(`ZenFi pagamentos na porta ${port}`));
}
module.exports = server;

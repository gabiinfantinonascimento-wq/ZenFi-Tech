// Armazenamento simples em arquivo JSON.
// Para usar seu banco (MySQL, Postgres, Mongo...), reimplemente apenas estas 4 funções
// mantendo a mesma assinatura.
const fs = require('fs');
const path = require('path');

const FILE = process.env.DATA_FILE || path.join(__dirname, '..', 'data', 'subscriptions.json');

function load() {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); }
  catch { return { users: {}, payments: {} }; }
}
function save(db) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, FILE); // escrita atômica
}

const norm = (e) => String(e || '').trim().toLowerCase();

function getUser(email) { return load().users[norm(email)] || null; }

function upsertUser(email, patch) {
  const db = load();
  const key = norm(email);
  db.users[key] = { ...(db.users[key] || {}), ...patch, email: key, updatedAt: new Date().toISOString() };
  save(db);
  return db.users[key];
}

// Evita processar o mesmo pagamento Pix duas vezes
function markPaymentProcessed(id) {
  const db = load();
  if (db.payments[id]) return false;
  db.payments[id] = new Date().toISOString();
  save(db);
  return true;
}

module.exports = { getUser, upsertUser, markPaymentProcessed, norm };

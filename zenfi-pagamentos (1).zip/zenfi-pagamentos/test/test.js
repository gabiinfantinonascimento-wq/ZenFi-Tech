// Teste local com um "Mercado Pago falso". Rode: npm test
const http = require('http');
const crypto = require('crypto');
const os = require('os'); const path = require('path'); const fs = require('fs');
const assert = require('assert');

const dataFile = path.join(os.tmpdir(), `zenfi-${Date.now()}.json`);
const state = { pre: {}, pay: {} };
const fake = http.createServer((req, res) => {
  const m = req.url.match(/^\/(preapproval|v1\/payments)\/(.+)$/);
  const body = m && (m[1] === 'preapproval' ? state.pre[m[2]] : state.pay[m[2]]);
  res.writeHead(body ? 200 : 404, { 'content-type': 'application/json' });
  res.end(JSON.stringify(body || {}));
});

fake.listen(0, async () => {
  Object.assign(process.env, {
    MP_API_BASE: `http://127.0.0.1:${fake.address().port}`, MP_ACCESS_TOKEN: 't',
    MP_WEBHOOK_SECRET: 'segredo', APP_API_KEY: 'k', DATA_FILE: dataFile,
  });
  const srv = require('../src/server.js');
  srv.listen(0);
  const base = `http://127.0.0.1:${srv.address().port}`;

  const post = (type, id, sign = true) => {
    const ts = String(Date.now()), rid = 'req-' + id;
    const sig = crypto.createHmac('sha256', 'segredo').update(`id:${String(id).toLowerCase()};request-id:${rid};ts:${ts};`).digest('hex');
    return fetch(`${base}/webhook/mercadopago?data.id=${id}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-request-id': rid, 'x-signature': `ts=${ts},v1=${sign ? sig : 'errada'}` },
      body: JSON.stringify({ type, data: { id } }),
    });
  };
  const status = async (email) => (await fetch(`${base}/api/subscription?email=${email}`, { headers: { authorization: 'Bearer k' } })).json();
  const wait = () => new Promise((r) => setTimeout(r, 150));

  // 1. assinatura sem assinatura válida é rejeitada
  assert.strictEqual((await post('subscription_preapproval', 'A1', false)).status, 401);

  // 2. assinatura autorizada libera acesso
  state.pre.A1 = { id: 'A1', status: 'authorized', payer_email: 'Ana@Email.com', next_payment_date: new Date(Date.now() + 30 * 864e5).toISOString() };
  assert.strictEqual((await post('subscription_preapproval', 'A1')).status, 200); await wait();
  let s = await status('ana@email.com'); assert.ok(s.active, 'ana ativa'); assert.strictEqual(s.status, 'authorized');

  // 3. cancelada: mantém o já pago, não estende
  const before = s.accessUntil;
  state.pre.A1.status = 'cancelled'; await post('subscription_preapproval', 'A1'); await wait();
  s = await status('ana@email.com'); assert.strictEqual(s.accessUntil, before); assert.strictEqual(s.status, 'cancelled');

  // 4. Pix aprovado libera ~31 dias, e não duplica
  state.pay['P1'] = { id: 'P1', status: 'approved', payment_method_id: 'pix', transaction_amount: 44.9, payer: { email: 'bia@email.com' } };
  await post('payment', 'P1'); await wait();
  s = await status('bia@email.com'); assert.ok(s.active, 'bia ativa');
  const t1 = s.accessUntil; await post('payment', 'P1'); await wait();
  assert.strictEqual((await status('bia@email.com')).accessUntil, t1, 'sem duplicar');

  // 5. Pix de valor menor não libera
  state.pay['P2'] = { id: 'P2', status: 'approved', payment_method_id: 'pix', transaction_amount: 10, payer: { email: 'caio@email.com' } };
  await post('payment', 'P2'); await wait();
  assert.ok(!(await status('caio@email.com')).active);

  // 6. consulta sem chave é negada
  assert.strictEqual((await fetch(`${base}/api/subscription?email=x`)).status, 401);

  console.log('OK: todos os testes passaram');
  srv.close(); fake.close(); fs.rmSync(dataFile, { force: true });
});
